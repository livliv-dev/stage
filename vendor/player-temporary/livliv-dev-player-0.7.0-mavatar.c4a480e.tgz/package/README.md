<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="media/livliv-player-wordmark-white.svg">
    <img alt="LivLiv Player" src="media/livliv-player-wordmark-2000.png" width="360">
  </picture>
</p>

<p align="center">
  A lightweight 2.5D character player for the web, with lip sync and webcam face tracking. A few lines of code put a character in a page, a stream overlay or an app.<br>
  Comes with 23 featured characters in different styles, ready to use.
</p>

<p align="center"><b>English</b> · <a href="README.zh-CN.md">中文</a> · <a href="README.ja.md">日本語</a> · <a href="README.vi.md">Tiếng Việt</a></p>

<p align="center"><img src="media/demo.gif" alt="Featured characters breathing, blinking, turning their heads and talking" width="720"></p>

- WebGL2, no dependencies, about 30 KB gzipped for the core
- Lip sync (microphone, audio, video) and webcam face tracking (MediaPipe), both in the browser, imported only when you need them
- Plays LivLiv, VRM, PNGTuber and Mesh Avatar Studio (`.mavatar`) characters through the same API
- Full-body characters stand on the ground: they sway, crouch and dip with their feet in place, in the shot you pick
- 23 featured characters in [`characters/`](characters/), ready to use

## Try it

- **Online**: the examples run on [livliv-dev.github.io/player](https://livliv-dev.github.io/player/).
- **Here**: `npm install && npm run build`, serve this folder with any static server and open `/example/demo.html`
  (expressions, actions, microphone, camera; `?model=../characters/<id>/` picks another character).
  `/example/png.html`, `/example/vrm.html` and `/example/mavatar.html` show a PNGTuber, a VRM and a Mesh Avatar Studio avatar.
- **On livliv.ai**: each character's page there plays it with the same renderer. Start at
  [livliv.ai/discover](https://livliv.ai/discover).

## Project LivLiv

We want the art of creating characters to belong to everyone.

We're open-sourcing our AI tools for character creation, [the player and its playback protocol](https://github.com/livliv-dev/player),
and [a stage where your characters can meet an audience](https://github.com/livliv-dev/stage).

Come say hello on [Discord](https://discord.gg/ac5qF36T2H) and follow us on [X (Twitter)](https://x.com/livliv_ai).

## Use it in your page

```sh
npm install @livliv-dev/player
```

```js
import { Player } from '@livliv-dev/player'

const player = new Player(document.querySelector('canvas'))
await player.load('characters/k01/')   // a folder with model.json and textures/, or a .livliv file

player.setExpression('smile')          // ids are in player.expressions
player.act('nod')
player.params.mouthOpen = 0.6          // 0..1
```

Lip sync and face tracking:

```js
import { createSpeech } from '@livliv-dev/player/voice'
import { startFaceTracking } from '@livliv-dev/player/tracking'   // needs @mediapipe/tasks-vision

const speech = createSpeech(player)
button.onclick = () => { speech.unlock(); speech.say('/reply.mp3') }

await startFaceTracking(player)
```

A VRM, a PNGTuber or a Mesh Avatar Studio avatar, on the same API:

```js
import { BodyPlayer } from '@livliv-dev/player/body'
import { VrmBody } from '@livliv-dev/player/vrm'          // needs three and @pixiv/three-vrm
import { PngBody } from '@livliv-dev/player/png'
import { MavatarBody } from '@livliv-dev/player/mavatar'  // needs mesh-avatar

const vrm = new BodyPlayer(canvasA, new VrmBody())
await vrm.load('/avatars/me.vrm')
const png = new BodyPlayer(canvasB, new PngBody())
await png.load({ closed: 'me-closed.png', open: 'me-open.png' })
const mesh = new BodyPlayer(canvasC, new MavatarBody())
await mesh.load('/avatars/me.mavatar')
```

The whole API is in [API.md](API.md): options, params, expressions and actions, feel settings, drivers, recorded poses and attachment
points, VRM, PNGTuber and `.mavatar` characters, the limits on untrusted files, the model package and the format version. The LivLiv package format (`.livliv`,
`model.json` v4) is in [FORMAT.md](FORMAT.md), with a JSON Schema in [`schema/`](schema/); packages exported before v4
are described in [FORMAT-v3.md](FORMAT-v3.md) and still play.

**New in 0.7 (not released yet):** Mesh Avatar Studio avatars (`.mavatar`) play on a `BodyPlayer` with
`@livliv-dev/player/mavatar`, drawn by their own runtime, [mesh-avatar](https://www.npmjs.com/package/mesh-avatar) (MIT),
which you install next to the player. The Player's idle motion, lip sync, face tracking and expressions move them. Pages
written for 0.6 need no change. See [Characters that aren't LivLiv models](API.md#characters-that-arent-livliv-models-livliv-devplayerbody).

**New in 0.6:** long hair swings below the shoulders as the head and body move (a model's `tuning.hair_sway` sets how
far; 0 turns it off), and long hair lying on the body goes with the body, not the head (`tuning.hair_rest`). A
character's feel settings (`tuning`: how far it turns, how freely its hair swings, how often it blinks …) can be read
with `player.tuning` and changed while it plays with `player.setTuning()`, for an editor's sliders, and
`load(source, { continueMotion: true })` keeps a character moving when an edit loads it again. VRM files exported from
Blender play. Code that runs its own frame loop can take the renderer itself from an advanced entry,
`@livliv-dev/player/runtime`. Pages written for 0.5 need no change. See [Feel settings](API.md#feel-settings-tuning-and-settuning) in API.md.

> The npm package is the player alone. The featured characters are in this repository's [`characters/`](characters/): copy
> the ones you use next to your page, with their licence.

## Featured characters

`characters/` holds 23 characters, ready to `load()`. Most were made by LivLiv: use them free with credit
("Characters: LivLiv (livliv.ai)"), commercially too if you are an individual. Don't sell them or merchandise made from
them, and don't train AI models on them. They are **not** covered by the Apache License; the terms are in
[characters/LICENSE.md](characters/LICENSE.md). Kujira, Kujira Q and Pen come from other people's work, with their own
terms in [characters/CREDITS.md](characters/CREDITS.md).

**New in 0.5.0: full-body characters.** Drawn head to feet, they stand on the ground: they sway, crouch and dip while
their feet stay put. Four featured characters are full-body: Tsubaki, Neve, Juno and Viola (f05–f08). Pick the shot
with `player.view.fit`: `'frame'` (default), `'knee'` or `'whole'`; see
[Full-body characters](API.md#full-body-characters) in API.md.

Each character has a `cover.webp`, its first frame: `player.load(source, { poster })` shows it until the character is
ready, and [example/loading.js](example/loading.js) shows it before any script has run.

Each character is also one file to download, `<id>.livliv`, at `https://livliv-dev.github.io/player/characters/<id>.livliv`
(the names below link to them). They are served with CORS, so a page on another site can `load()` one straight from
there, and [`index.json`](https://livliv-dev.github.io/player/characters/index.json) lists them all.

| id | name | id | name | id | name |
|---|---|---|---|---|---|
| `k01` | [Sena](https://livliv-dev.github.io/player/characters/k01.livliv) | `k02` | [Elio](https://livliv-dev.github.io/player/characters/k02.livliv) | `char06` | [Aoi](https://livliv-dev.github.io/player/characters/char06.livliv) |
| `char07` | [Sora](https://livliv-dev.github.io/player/characters/char07.livliv) | `s01` | [Hana](https://livliv-dev.github.io/player/characters/s01.livliv) | `d01` | [Yui](https://livliv-dev.github.io/player/characters/d01.livliv) |
| `d02` | [Leo](https://livliv-dev.github.io/player/characters/d02.livliv) | `d03` | [Nana](https://livliv-dev.github.io/player/characters/d03.livliv) | `d03ft` | [Nana (refined)](https://livliv-dev.github.io/player/characters/d03ft.livliv) |
| `v01` | [Aster](https://livliv-dev.github.io/player/characters/v01.livliv) | `v03` | [Mira](https://livliv-dev.github.io/player/characters/v03.livliv) | `v04` | [Kai](https://livliv-dev.github.io/player/characters/v04.livliv) |
| `v05` | [Lilith](https://livliv-dev.github.io/player/characters/v05.livliv) | `v06` | [Usa](https://livliv-dev.github.io/player/characters/v06.livliv) | `v07` | [Stella](https://livliv-dev.github.io/player/characters/v07.livliv) |
| `w01` | [Max](https://livliv-dev.github.io/player/characters/w01.livliv) | `p01` | [Kujira](https://livliv-dev.github.io/player/characters/p01.livliv) | `p02` | [Kujira Q](https://livliv-dev.github.io/player/characters/p02.livliv) |
| `p03` | [Pen](https://livliv-dev.github.io/player/characters/p03.livliv) | `f05` | [Tsubaki (full-body)](https://livliv-dev.github.io/player/characters/f05.livliv) | `f06` | [Neve (full-body)](https://livliv-dev.github.io/player/characters/f06.livliv) |
| `f07` | [Juno (full-body)](https://livliv-dev.github.io/player/characters/f07.livliv) | `f08` | [Viola (full-body)](https://livliv-dev.github.io/player/characters/f08.livliv) | | |

## Characters of your own

You can bring in a PNGTuber's pictures, a VRM (drawn with three.js) or a Mesh Avatar Studio avatar (drawn by
mesh-avatar); or make a character of your own from one picture on [livliv.ai](https://livliv.ai).

- **A PNGTuber**: two pictures (mouth closed, mouth open), and two more with the eyes closed if you have them.
- **A VRM**: from VRoid Studio or any tool that exports VRM 0.x or 1.0.
- **A Mesh Avatar Studio avatar**: a `.mavatar` exported from [Mesh Avatar Studio](https://github.com/shinshin86/mesh-avatar-studio),
  which makes a moving avatar from one picture.
- **A LivLiv model**: make one from a picture on [livliv.ai](https://livliv.ai), then download its model package from
  the character's page (**Model package**): a `.livliv` file. Pass it to `load()` as it is (a URL, or the `File`
  someone picked), or unzipped as a folder. Full-body characters play too (from 0.5); livliv.ai does not offer their
  packages yet.

## About the player and the characters

LivLiv Player and the `.livliv` format are LivLiv's own work. They use no Live2D software or Cubism SDK and do not
read `.moc3` or `.cmo3` files. "Live2D" is a trademark of Live2D Inc.; LivLiv is not affiliated with it.

Making a character on livliv.ai uses AI. The player itself only plays: it calls no AI service and reads only the files
you point it at. Face tracking runs Google's MediaPipe in the browser, and camera images stay on the device; API.md has
the networking details.

The featured characters in this repository were made on LivLiv too, also with AI; Kujira, Kujira Q and Pen adapt other
people's characters ([credits](characters/CREDITS.md)). Refined Nana (`d03ft`) also has
swinging parts and head-turn keyforms added with LivLiv's own tools.

A package's `meta.author` and `meta.license` record who made it and on what terms: keep them and follow them. When you
show a character made with LivLiv in public, say that AI was used to make it, and don't present it as hand-drawn or
hand-rigged.

## Embed without code

```html
<iframe src="https://livliv.ai/live/k01" width="480" height="640" allow="camera; microphone"
  style="border:0;background:transparent"></iframe>
```

The same `/live/<id>` page has a transparent background and works as an OBS Browser Source.\
(Powered by [https://livliv.ai](https://livliv.ai))

## Develop

```sh
git clone https://github.com/livliv-dev/player
cd player
npm install
npm run check          # types
npm run build          # dist/: index.js, tracking.js, voice.js, body.js, png.js, vrm.js, mavatar.js (ES modules), chunks/ and types/
npm test               # unit and fuzz tests (Node 22.18 or newer, no browser)
npm run test:browser   # every featured character drawn in headless Chromium; once: npx playwright-core install chromium-headless-shell
npm run test:engines   # a sample on Firefox and WebKit, where WebGL2 starts (a GPU or a software GL); once: npx playwright-core install firefox webkit
```

`src/runtime/` is the renderer and motion code livliv.ai runs; this repository is published from it. See
[CONTRIBUTING.md](CONTRIBUTING.md). Security reports: [SECURITY.md](SECURITY.md).

## Browser support

WebGL2 and ES2023: Chrome / Edge 97+, Firefox 104+, Safari 15.4+. Tested on current desktop browsers, not yet on phones.

## License

The code is under the [Apache License 2.0](LICENSE) (see also [NOTICE](NOTICE)). The featured characters have their
own licence, [characters/LICENSE.md](characters/LICENSE.md). mesh-avatar, which draws `.mavatar` avatars, is a separate
package under the MIT License. You may keep the LivLiv name and logo in your own versions, as long as they don't claim to be the official one.

## Thanks

Thanks to 上善无形, ZipZipPipe and 贱兔死顺盖, whose characters Kujira, Kujira Q and Pen are based on: see [characters/CREDITS.md](characters/CREDITS.md).

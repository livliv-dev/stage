<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="media/livliv-player-wordmark-white.svg">
    <img alt="LivLiv Player" src="media/livliv-player-wordmark-2000.png" width="360">
  </picture>
</p>

<p align="center">
  超軽量の Web 向けキャラクタープレイヤー。リップシンクと Web カメラのフェイストラッキングに対応し、数行のコードでページや配信画面、アプリに組み込めます。<br>
  さまざまなスタイルの厳選キャラクター 23 体を同梱。すぐに使えます。
</p>

<p align="center"><a href="README.md">English</a> · <a href="README.zh-CN.md">中文</a> · <b>日本語</b> · <a href="README.vi.md">Tiếng Việt</a></p>

<p align="center"><img src="media/demo.gif" alt="厳選キャラクターが呼吸し、まばたきし、振り向き、話す様子" width="720"></p>

- WebGL2、依存なし、コアは gzip で約 30 KB
- リップシンク（マイク、音声、動画）と Web カメラのフェイストラッキング（MediaPipe）はブラウザ内で動作し、必要なときだけ読み込めます
- LivLiv・VRM・PNGTuber・Mesh Avatar Studio（`.mavatar`）のキャラクターを同じ API で再生
- 全身のキャラクターは足を地面に着けたまま、揺れ、しゃがみ、話すと上半身が沈みます。表示範囲も選べます
- [`characters/`](characters/) に厳選キャラクター 23 体。すぐに使えます

## 試してみる

- **オンラインで**：デモページは [livliv-dev.github.io/player](https://livliv-dev.github.io/player/) にあります。
- **手元で**：`npm install && npm run build` のあと、このフォルダを静的サーバーで配信して `/example/demo.html` を開きます
  （表情、アクション、マイク、カメラ。`?model=../characters/<id>/` でキャラクターを切り替え）。`/example/png.html`、
  `/example/vrm.html`、`/example/mavatar.html` は PNGTuber、VRM、Mesh Avatar Studio のアバターです。
- **livliv.ai で**：各キャラクターのページで、同じレンダラーがそのキャラクターを動かしています。[livliv.ai/discover](https://livliv.ai/discover) からどうぞ。

## Project LivLiv

誰もが、思い描いたキャラクターをかたちにできるように。それが私たちの願いです。

AI を使ったキャラクター制作のツール群、[プレイヤーとその再生プロトコル](https://github.com/livliv-dev/player)、そして[キャラクターをお披露目できる舞台](https://github.com/livliv-dev/stage)をオープンソース化しています。

ぜひ [Discord](https://discord.gg/ac5qF36T2H) に遊びに来てください。[X（Twitter）](https://x.com/livliv_ai) でも LivLiv をフォローしてもらえたらうれしいです。

## 自分のページで使う

```sh
npm install @livliv-dev/player
```

```js
import { Player } from '@livliv-dev/player'

const player = new Player(document.querySelector('canvas'))
await player.load('characters/k01/')   // model.json と textures/ のあるフォルダ、または .livliv ファイル

player.setExpression('smile')          // 使える id は player.expressions に
player.act('nod')
player.params.mouthOpen = 0.6          // 0..1
```

リップシンクとフェイストラッキング：

```js
import { createSpeech } from '@livliv-dev/player/voice'
import { startFaceTracking } from '@livliv-dev/player/tracking'   // @mediapipe/tasks-vision が必要

const speech = createSpeech(player)
button.onclick = () => { speech.unlock(); speech.say('/reply.mp3') }

await startFaceTracking(player)
```

VRM、PNGTuber、Mesh Avatar Studio のアバターも同じ API で：

```js
import { BodyPlayer } from '@livliv-dev/player/body'
import { VrmBody } from '@livliv-dev/player/vrm'          // three と @pixiv/three-vrm が必要
import { PngBody } from '@livliv-dev/player/png'
import { MavatarBody } from '@livliv-dev/player/mavatar'  // mesh-avatar が必要

const vrm = new BodyPlayer(canvasA, new VrmBody())
await vrm.load('/avatars/me.vrm')
const png = new BodyPlayer(canvasB, new PngBody())
await png.load({ closed: 'me-closed.png', open: 'me-open.png' })
const mesh = new BodyPlayer(canvasC, new MavatarBody())
await mesh.load('/avatars/me.mavatar')
```

API の全体は [API.md](API.md)（英語）にあります：オプション、パラメーター、表情とアクション、動きの調整、ドライバー、記録したポーズと取り付け位置、VRM・PNGTuber・`.mavatar`、信頼できないファイルの上限、モデルパッケージ、フォーマットのバージョン。LivLiv のパッケージ形式（`.livliv`、`model.json` v4）は [FORMAT.md](FORMAT.md)、JSON Schema は [`schema/`](schema/) にあります。v4 より前に書き出したパッケージは [FORMAT-v3.md](FORMAT-v3.md) のとおりで、そのまま再生できます。

**0.7 の新機能（未リリース）：** `@livliv-dev/player/mavatar` で、Mesh Avatar Studio のアバター（`.mavatar`）を `BodyPlayer` で再生できます。描画はこの形式のランタイム [mesh-avatar](https://www.npmjs.com/package/mesh-avatar)（MIT）が行うので、プレイヤーと一緒にインストールしてください。プレイヤーの待機モーション、リップシンク、フェイストラッキング、表情で動きます。0.6 向けに書いたページは変更不要です。詳しくは API.md の [Characters that aren't LivLiv models](API.md#characters-that-arent-livliv-models-livliv-devplayerbody) をご覧ください。

**0.6 の新機能：** 頭や体が動くと、肩より下の長い髪が左右に揺れます（モデルの `tuning.hair_sway` で揺れ幅を調整、0 で無効）。体にかかった長い髪は、頭ではなく体について動きます（`tuning.hair_rest`）。まばたきの途中で虹彩が半透明に透けて見えることもなくなりました。キャラクターの動きの調整（`tuning`：首の回り具合、髪の揺れ、まばたきの頻度など）は `player.tuning` で読み取り、`player.setTuning()` で再生中にそのまま変更できるので、エディターのスライダーに使えます。`load(source, { continueMotion: true })` を使えば、編集のたびに読み込み直しても動きが途切れません。Blender から書き出した VRM も再生できるようになりました。独自のフレームループを回すコードは、上級者向けの入口 `@livliv-dev/player/runtime` からレンダラーそのものを使えます。0.5 向けに書いたページは変更不要です。詳しくは API.md の [Feel settings](API.md#feel-settings-tuning-and-settuning) をご覧ください。

> npm パッケージに入っているのはプレイヤーだけです。厳選キャラクターはこのリポジトリの [`characters/`](characters/) にあります。使うキャラクターをライセンスと一緒にページのそばにコピーしてください。

## 厳選キャラクター

`characters/` には 23 体のキャラクターが入っていて、そのまま `load()` できます。大半は LivLiv が制作したもので、クレジット（「キャラクター：LivLiv（livliv.ai）」）を入れれば無料で使え、個人なら商用利用もできます。キャラクター自体やグッズの販売、AI モデルの学習には使えません。これらには Apache License は**適用されません**。条文は [characters/LICENSE.md](characters/LICENSE.md) をご覧ください。Kujira、Kujira Q、Pen は他の方の作品に基づくもので、条件は [characters/CREDITS.md](characters/CREDITS.md) にあります。

**0.5.0 の新機能：全身のキャラクター。** 頭から足まで描かれ、地面に立っています。足を着けたまま揺れ、しゃがみ、話すと上半身が沈みます。厳選キャラクターのうち Tsubaki、Neve、Juno、Viola（f05〜f08）の 4 体が全身です。表示範囲は `player.view.fit` で `'frame'`（既定）、`'knee'`、`'whole'` から選べます。詳しくは API.md の [Full-body characters](API.md#full-body-characters) をご覧ください。

各キャラクターには最初のフレームの `cover.webp` があります。`player.load(source, { poster })` を使うと、準備ができるまでそれを表示します。スクリプトが動く前から表示する方法は [example/loading.js](example/loading.js) にあります。

各キャラクターは 1 つのファイル `<id>.livliv` としてもダウンロードできます。場所は `https://livliv-dev.github.io/player/characters/<id>.livliv` です。CORS 付きで配信しているので、別のサイトのページからもそこから直接 `load()` できます。全キャラクターの一覧は [`index.json`](https://livliv-dev.github.io/player/characters/index.json) にあります。キャラクターの一覧とダウンロードリンクは[英語の README](README.md#featured-characters) にあります。

## 自分のキャラクター

PNGTuber の画像、VRM（three.js で描画）、Mesh Avatar Studio のアバター（mesh-avatar で描画）を読み込めます。[livliv.ai](https://livliv.ai) で 1 枚の絵から自分のキャラクターを作ることもできます。

- **PNGTuber**：2 枚の画像（口を閉じた絵、開いた絵）。目を閉じた 2 枚もあればなお良いです。
- **VRM**：VRoid Studio など、VRM 0.x / 1.0 を書き出せるツールで作ったもの。
- **Mesh Avatar Studio のアバター**：[Mesh Avatar Studio](https://github.com/shinshin86/mesh-avatar-studio) で書き出した `.mavatar`。1 枚の絵から動くアバターを作るツールです。
- **LivLiv のモデル**：[livliv.ai](https://livliv.ai) で 1 枚の絵からキャラクターを作り、キャラクターページから**モデルパッケージ**（`.livliv` ファイル）をダウンロードします。そのまま `load()` に渡せます（URL、または選んでもらった `File`）。展開したフォルダでも構いません。全身のキャラクターも再生できます（0.5 から）。livliv.ai ではまだ全身キャラクターのパッケージを提供していません。

## プレイヤーとキャラクターについて

LivLiv Player と `.livliv` 形式は LivLiv が独自に開発したもので、Live2D のソフトウェアや Cubism SDK は使っておらず、`.moc3` / `.cmo3` ファイルも読み込みません。「Live2D」は Live2D Inc. の商標であり、LivLiv は同社と提携していません。

livliv.ai でのキャラクター制作には AI を使います。プレイヤー自体は再生するだけです。AI のサービスを呼び出すことはなく、指定されたファイルだけを読み込みます。フェイストラッキングはブラウザ内で Google の MediaPipe を動かし、カメラの映像は端末の外に出ません。通信について詳しくは API.md をご覧ください。

このリポジトリの厳選キャラクターも LivLiv で作ったもので、同じく AI を使っています。Kujira、Kujira Q、Pen は他の方のキャラクターを翻案したものです（[クレジット](characters/CREDITS.md)）。Nana のリファイン版（`d03ft`）には、LivLiv 独自のツールで揺れるパーツと振り向きのキーフォームを加えています。

パッケージの `meta.author` と `meta.license` は、クレジットと利用条件を記したものです。残したうえで従ってください。LivLiv で作ったキャラクターを公開するときは AI が制作に関わっていることを明記し、手描きや手作業のリギングによる作品として紹介しないでください。

## コードを書かずに埋め込む

```html
<iframe src="https://livliv.ai/live/k01" width="480" height="640" allow="camera; microphone"
  style="border:0;background:transparent"></iframe>
```

同じ `/live/<id>` ページは背景が透明なので、そのまま OBS のブラウザソースに使えます。\
(Powered by [https://livliv.ai](https://livliv.ai))

## 開発

```sh
git clone https://github.com/livliv-dev/player
cd player
npm install
npm run check          # 型チェック
npm run build          # dist/：index.js、tracking.js、voice.js、body.js、png.js、vrm.js、mavatar.js（ES モジュール）、chunks/ と types/
npm test               # ユニットテストとファジング（Node 22.18 以降、ブラウザ不要）
npm run test:browser   # ヘッドレス Chromium で全キャラクターを描画。最初に一度 npx playwright-core install chromium-headless-shell
npm run test:engines   # Firefox と WebKit で小さなサンプルを実行。WebGL2 が動く環境（GPU かソフトウェア GL）が必要。最初に一度 npx playwright-core install firefox webkit
```

`src/runtime/` は livliv.ai 自身が使っているレンダラーとモーションのコードで、このリポジトリはそこから公開しています。[CONTRIBUTING.md](CONTRIBUTING.md) もご覧ください。セキュリティの問題は [SECURITY.md](SECURITY.md) のとおりにご報告ください。

## 対応ブラウザ

WebGL2 と ES2023 が必要です：Chrome / Edge 97+、Firefox 104+、Safari 15.4+。テスト済みなのはデスクトップの最新版で、スマートフォンはまだテストしていません。

## ライセンス

コードは [Apache License 2.0](LICENSE) です（[NOTICE](NOTICE) も参照）。厳選キャラクターには別のライセンス [characters/LICENSE.md](characters/LICENSE.md) があります。`.mavatar` を描画する mesh-avatar は別パッケージで、MIT License です。LivLiv の名前とロゴは、公式版を名乗らない限り、あなたのバージョンでもそのまま使えます。

## 謝辞

Kujira、Kujira Q、Pen の元になったキャラクターの作者である上善无形さん、ZipZipPipe さん、贱兔死顺盖さんに感謝します。詳しくは [characters/CREDITS.md](characters/CREDITS.md) をご覧ください。

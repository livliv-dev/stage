<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="media/livliv-player-wordmark-white.svg">
    <img alt="LivLiv Player" src="media/livliv-player-wordmark-2000.png" width="360">
  </picture>
</p>

<p align="center">
  超轻量的 2.5D 网页角色播放器，支持口型同步和摄像头面捕，几行代码就能接入网页、直播画面和应用。<br>
  自带 23 个风格各异的精选角色，即开即用。
</p>

<p align="center"><a href="README.md">English</a> · <b>中文</b> · <a href="README.ja.md">日本語</a> · <a href="README.vi.md">Tiếng Việt</a></p>

<p align="center"><img src="media/demo.gif" alt="精选角色在呼吸、眨眼、转头、说话" width="720"></p>

特点：

- WebGL2，无依赖，核心 gzip 后约 30 KB
- 口型同步（麦克风、音频、视频）和摄像头面捕（MediaPipe），都在浏览器里运行，按需引入
- 支持 LivLiv、VRM、PNGTuber 和 Mesh Avatar Studio（`.mavatar`）四种角色，用同一套接口
- 全身角色双脚站在地面上：会晃、会蹲，说话时上身轻轻一沉，取景自己选
- [`characters/`](characters/) 里有 23 个精选角色，可以直接用

## 试一试

- **在线**：示例页在 [livliv-dev.github.io/player](https://livliv-dev.github.io/player/)。
- **在本地**：`npm install && npm run build`，用任意静态服务器打开这个目录，访问 `/example/demo.html`
  （表情、动作、麦克风、摄像头；`?model=../characters/<id>/` 换一个角色）。`/example/png.html`、
  `/example/vrm.html` 和 `/example/mavatar.html` 是 PNGTuber、VRM 和 Mesh Avatar Studio 角色。
- **在 livliv.ai 上**：那里的每个角色页都用同一套渲染播放这个角色。从 [livliv.ai/discover](https://livliv.ai/discover) 开始。

## Project LivLiv

我们希望，创造角色这件事能属于每一个人。

我们正在开源 AI 角色创作工具链、[播放器与播放协议](https://github.com/livliv-dev/player)，还有[一方舞台，让你创作的角色与大家见面](https://github.com/livliv-dev/stage)。

欢迎来 [Discord](https://discord.gg/ac5qF36T2H) 聊聊角色创作，也可以在 [X（Twitter）](https://x.com/livliv_ai) 上关注我们。

## 在自己的页面里用

```sh
npm install @livliv-dev/player
```

```js
import { Player } from '@livliv-dev/player'

const player = new Player(document.querySelector('canvas'))
await player.load('characters/k01/')   // 含 model.json 和 textures/ 的文件夹，或一个 .livliv 文件

player.setExpression('smile')          // 可用的 id 在 player.expressions 里
player.act('nod')
player.params.mouthOpen = 0.6          // 0..1
```

口型同步和面捕：

```js
import { createSpeech } from '@livliv-dev/player/voice'
import { startFaceTracking } from '@livliv-dev/player/tracking'   // 需要 @mediapipe/tasks-vision

const speech = createSpeech(player)
button.onclick = () => { speech.unlock(); speech.say('/reply.mp3') }

await startFaceTracking(player)
```

VRM、PNGTuber 和 Mesh Avatar Studio 角色用同一套接口：

```js
import { BodyPlayer } from '@livliv-dev/player/body'
import { VrmBody } from '@livliv-dev/player/vrm'          // 需要 three 和 @pixiv/three-vrm
import { PngBody } from '@livliv-dev/player/png'
import { MavatarBody } from '@livliv-dev/player/mavatar'  // 需要 mesh-avatar

const vrm = new BodyPlayer(canvasA, new VrmBody())
await vrm.load('/avatars/me.vrm')
const png = new BodyPlayer(canvasB, new PngBody())
await png.load({ closed: 'me-closed.png', open: 'me-open.png' })
const mesh = new BodyPlayer(canvasC, new MavatarBody())
await mesh.load('/avatars/me.mavatar')
```

完整的 API 见 [API.md](API.md)（英文）：选项、参数、表情和动作、手感设置、驱动、录下的姿态和挂点、VRM、PNGTuber 和 `.mavatar`、不可信文件的上限、模型包和格式版本。LivLiv 模型包格式（`.livliv`、`model.json` v4）见 [FORMAT.md](FORMAT.md)，JSON Schema 在 [`schema/`](schema/)；v4 之前导出的模型包见 [FORMAT-v3.md](FORMAT-v3.md)，照样能播放。

**0.7 新增（尚未发布）：** `@livliv-dev/player/mavatar` 让 Mesh Avatar Studio 角色（`.mavatar`）在 `BodyPlayer` 上播放，由它自己的运行库 [mesh-avatar](https://www.npmjs.com/package/mesh-avatar)（MIT）绘制，需要和播放器一起安装。播放器的待机动作、口型、面捕和表情都能驱动它。为 0.6 写的页面无需改动。详见 API.md 的 [Characters that aren't LivLiv models](API.md#characters-that-arent-livliv-models-livliv-devplayerbody)。

**0.6 新增：** 头和身体动起来时，肩膀以下的长发会左右摆动（模型的 `tuning.hair_sway` 控制幅度，设为 0 即关闭）。角色的手感设置（`tuning`：转头幅度、头发晃动、眨眼频率等）可以用 `player.tuning` 读取，用 `player.setTuning()` 在播放中直接修改，适合编辑器的滑块；`load(source, { continueMotion: true })` 让编辑后重新加载的角色接着原来的动作继续动。Blender 导出的 VRM 文件也能播放了。自己跑帧循环的代码可以从高级入口 `@livliv-dev/player/runtime` 直接拿到渲染器。为 0.5 写的页面无需改动。详见 API.md 的 [Feel settings](API.md#feel-settings-tuning-and-settuning)。

> npm 包里只有播放器。精选角色在这个仓库的 [`characters/`](characters/) 里，把要用的角色连同许可一起复制到你的页面旁边。

## 精选角色

`characters/` 里有 23 个角色，可以直接 `load()`。大部分由 LivLiv 制作：署名（「角色：LivLiv（livliv.ai）」）就能免费使用，个人也可以商用；不能出售角色本身或做成周边出售，不能用来训练 AI 模型。它们**不**适用 Apache 许可，完整条款见 [characters/LICENSE.md](characters/LICENSE.md)。Kujira、Kujira Q 和 Pen 来自别人的作品，条款见 [characters/CREDITS.md](characters/CREDITS.md)。

**0.5.0 新增全身角色。** 全身角色从头画到脚，双脚站在地面上：会晃、会蹲，说话时上身轻轻一沉，脚不离地。精选角色里有 4 个全身角色：Tsubaki、Neve、Juno、Viola（f05–f08）。用 `player.view.fit` 选取景：`'frame'`（默认）、`'knee'` 或 `'whole'`，详见 API.md 的 [Full-body characters](API.md#full-body-characters)。

每个角色都带一张 `cover.webp`，是它的第一帧：`player.load(source, { poster })` 会在角色准备好之前显示它；想在脚本运行前就显示，可以参考 [example/loading.js](example/loading.js)。

每个角色也是一个可以下载的单文件 `<id>.livliv`，地址是 `https://livliv-dev.github.io/player/characters/<id>.livliv`。它们带 CORS，别的网站上的页面也能直接从那里 `load()`；[`index.json`](https://livliv-dev.github.io/player/characters/index.json) 列出了全部角色。角色列表和下载链接见[英文 README](README.md#featured-characters)。

## 用自己的角色

可以导入 PNGTuber 的几张图、VRM（用 three.js 画）或 Mesh Avatar Studio 角色（用 mesh-avatar 画）；也可以在 [livliv.ai](https://livliv.ai) 用一张图做出自己的角色。

- **PNGTuber**：两张图（闭嘴、张嘴），有闭眼的两张更好。
- **VRM**：VRoid Studio 或任何能导出 VRM 0.x / 1.0 的工具做的。
- **Mesh Avatar Studio 角色**：[Mesh Avatar Studio](https://github.com/shinshin86/mesh-avatar-studio) 导出的 `.mavatar`，它用一张图做出会动的角色。
- **LivLiv 模型**：在 [livliv.ai](https://livliv.ai) 用一张图做出角色，在角色页下载**模型包**（一个 `.livliv` 文件），直接传给 `load()`（URL，或用户选的 `File`），解压后的文件夹也可以。全身角色也能播放（0.5 起）；livliv.ai 暂时还不提供全身角色的模型包。

## 关于播放器和角色

LivLiv Player 和 `.livliv` 格式是 LivLiv 独立做的，没有用 Live2D 的软件或 Cubism SDK，也不读 `.moc3` / `.cmo3` 文件。「Live2D」是 Live2D Inc. 的商标，LivLiv 与其无关联。

在 livliv.ai 上制作角色会用到 AI。播放器本身只负责播放：不调用 AI 服务，只读取你指给它的文件。面捕在浏览器里运行 Google 的 MediaPipe，摄像头画面不离开设备；网络方面的细节见 API.md。

仓库里的精选角色也是在 LivLiv 上做的，同样用到了 AI；Kujira、Kujira Q 和 Pen 改编自别人的角色（[来源](characters/CREDITS.md)）。Nana 精修版（`d03ft`）另外用 LivLiv 自己的工具加了会摆动的部件和转头的关键形。

模型包里的 `meta.author` 和 `meta.license` 记的是署名和使用条款，请保留并遵守。公开展示用 LivLiv 做的角色时，请注明 AI 参与制作，不要说成手绘或人工绑定的作品。

## 不写代码，直接嵌入

```html
<iframe src="https://livliv.ai/live/k01" width="480" height="640" allow="camera; microphone"
  style="border:0;background:transparent"></iframe>
```

同一个 `/live/<id>` 页面背景透明，可以直接作为 OBS 的浏览器源。\
(Powered by [https://livliv.ai](https://livliv.ai))

## 开发

```sh
git clone https://github.com/livliv-dev/player
cd player
npm install
npm run check          # 类型检查
npm run build          # dist/：index.js、tracking.js、voice.js、body.js、png.js、vrm.js、mavatar.js（ES 模块）、chunks/ 和 types/
npm test               # 单元测试和模糊测试（Node 22.18 及以上，不需要浏览器）
npm run test:browser   # 在无头 Chromium 里画出每个精选角色；先执行一次 npx playwright-core install chromium-headless-shell
npm run test:engines   # 在 Firefox 和 WebKit 上跑一个小样本，机器要能启动 WebGL2（有 GPU 或软件 GL）；先执行一次 npx playwright-core install firefox webkit
```

`src/runtime/` 是 livliv.ai 自己在用的渲染和动作代码，这个仓库从它发布。参见 [CONTRIBUTING.md](CONTRIBUTING.md)。安全问题请按 [SECURITY.md](SECURITY.md) 报告。

## 浏览器支持

需要 WebGL2 和 ES2023：Chrome / Edge 97+、Firefox 104+、Safari 15.4+。目前在桌面最新版上测过，手机还没有测。

## 许可

代码采用 [Apache License 2.0](LICENSE)（另见 [NOTICE](NOTICE)）。精选角色有自己的许可：[characters/LICENSE.md](characters/LICENSE.md)。绘制 `.mavatar` 的 mesh-avatar 是另一个包，采用 MIT 许可。你的版本可以继续用 LivLiv 的名字和标志，只要不自称官方版本。

## 致谢

感谢上善无形、ZipZipPipe 和贱兔死顺盖，Kujira、Kujira Q 和 Pen 基于他们的角色，详见 [characters/CREDITS.md](characters/CREDITS.md)。
